#include "kernel/types.h"
#include "kernel/stat.h"
#include "kernel/spinlock.h"
#include "kernel/sleeplock.h"
#include "kernel/fs.h"
#include "kernel/file.h"
#include "user.h"
#include "kernel/fcntl.h"
#include "kernel/param.h"
#include "cp.h"


int
main(void){
    list();
    return 0;
}